Rebol [
    Title: "Include"
    File: %include.r
    Date: 22-Nov-2005/10:59:29+1:00
    Author: "Ladislav Mecir"
    Purpose: {
        A module manager
        
        INCLUDE CAN:
        
        - do scripts
        
        	- no special properties required, any Rebol script can be included
        	- INCLUDE-PATH is used to search for the files
		        - include-path can contain directories or URL's
        	- INCLUDE/CHECK can be used to prevent multiple include of a script
        	- scripts may contain preprocessing instructions:
				#include
				#include-check ; include if not included before
				#do
				#either
				#if
				#include-string
				#include-binary
			- official Rebol preprocessor compatible
			
        - build scripts using INCLUDE/LINK
        
        	- using the preprocessing instructions as above
        	- it is possible to include smaller parts than scripts, e.g.:
        		- binary data
        		- images
        		- strings
        	- context encapsulation available:
        	    make object! [#include %somefile.r]
    }
]

comment [
    ; Usage
    
    ; to find and do a file %myfile.r:
    include %myfile.r
    
    ; to append a URL or a directory to the search path:
    append include-path url-or-directory
    
    ; to find out, how the include-path looks:
    print include-path
    
    ; if you want to start using a totally new include-path:
    include-path: [%/my-search-dir/ %/etc/ http://www.myserv.dom/]
    
    ; to include %somefile.r if not included before:
    include/check %somefile.r
    
    ; to obtain a linked file:
    include/link %somefile.r %outfile.r
    
]
	
unless value? 'include [

	unless value? 'case [
		case: func [
			[throw catch]
		    args [block!] /local res
		] [
		    either unset? first res: do/next args [
		        if not empty? args [
		            ; invalid guard
		            throw  make error! [script no-arg case condition]
		        ]
		    ] [
		        either first res [
		            either block? first res: do/next second res [
		                do first res
		            ] [
		                ; not a block
		                throw make error! [
		                    script expect-arg case block [block!]
		                ]
		            ]
		        ] [
		            case second do/next second res
		        ]
		    ]
		]
	]
	
	make object! [
	
		split-path: function [
		    {
		        Splits a file or URL. Returns a block containing path and target.
		        
		        Overcomes some limitations of the Rebol/Core 2.2 split-path,
		        like strange results for:
		
		            split-path %file.r
		            split-path %""
		
		        The following equality holds:
		
		            file = append first split-path file second split-path file
		
		    }
		    file [file! url!]
		] [target] [
		    target: tail file
		    if (pick target -1) = #"/" [target: back target]
		    target: find/reverse target #"/"
		    target: either target [next target] [file]
		    reduce [copy/part file target to file! target]
		]
	
	    findpfile: function [
	    	{Find a file using the given search path}
	        path [block!]
	        file [file! url!]
	    ] [dir found] [
	        while [not empty? path] [
	            if exists? found: append dirize copy dir: first :path :file [
					return found
				]
	            path: next :path
	        ]
	        throw make error! reform ["Include error: file" file "not found"]
	    ]
	    
	    find-file: func [
	    	{Find a file using an appropriate search path}
			file [file! url!]
			/local dir target
		] [
	        set [dir target] split-path file
	    	findpfile either empty? :dir [include-path] [reduce [:dir]] target
	    ]	
	
	    ; include-path is initialized to contain the %. directory
	    ; and the directory, where the %include.r was run from
	    
	    set 'include-path reduce [%. system/script/path]
	
	    ; to prevent multiple includes
	    included-files: []
	    
	    set 'include func [
	        {A module manager}
	        [catch]
	        file [file! url!]
	        /check {include the script only if it hasn't been included before}
	        /link {create a linked file}
	        output [file!]
	        /local included include-script
		] [
			
		    include-script: func [
		    	{Include a script file}
		    	linked [block!]
				file [file! url!]
		    	check [none! logic!]
				/header
		    	link [none! logic!]
				/local included? result include-block binary-base tme found
				target dir
			] [
			
				tme: func [msg [string!] near [block!]] [
					throw make error! rejoin [
						msg newline
						"in file:" file newline
						"near:" copy/part mold/only near 40
					]
				]
			
			    include-block: func [
			    	linked [block! paren!]
			    	block [block! paren!]
			    	/local value value2 value3
			    ] [
			    	while [not tail? block] [
			    		case [
							any [block? first block paren? first block] [
								insert/only tail linked include-block make first block 0 first block
								block: next block
							]
							#include-check = first block [
				    			set/any [value value2] do/next next block
				    			any [
				    				file? get/any 'value
				    				url? get/any 'value
				    				tme "#include expected file or URL" block
								]
				    			include-script linked value true true
				    			block: value2
				    		]
							#include = first block [
				    			set/any [value value2] do/next next block
				    			any [
				    				file? get/any 'value
				    				url? get/any 'value
				    				tme "#include expected file or URL" block
								]
				    			include-script linked value none
				    			block: value2
				    		]
							#do = first block [
				    			any [
									block? set/any 'value pick block 2
									tme "#do expected a block" block
								]
								block: skip block 2
								insert tail linked do value
							]
							#if = first block [
				    			any [
									block? set/any 'value pick block 2
				    				tme "#if expected a condition block" block
								]
				    			any [
									block? set/any 'value2 pick block 3
				    				tme "#if expected a then-block" block
								]
								any [
									not unset? set/any 'value do value
									tme "#if condition must not yield unset!" block
								]
								any [not :value include-block linked value2]
								block: skip block 3
							]
			    			#either = first block [
				    			any [
									block? set/any 'value pick block 2
				    				tme "#either expected a condition block" block
								]
				    			any [
									block? set/any 'value2 pick block 3
				    				tme "#either expected a then-block" block
								]
				    			any [
									block? set/any 'value3 pick block 4
				    				tme "#either expected an else-block" block
								]
								any [
									not unset? set/any 'value do value
									tme "#either condition must not yield unset!" block
								]
								include-block linked either :value [value2] [value3]
								block: skip block 4
							]
							#include-string = first block [
				    			set/any [value value2] do/next next block
				    			any [
				    				file? get/any 'value
				    				url? get/any 'value
				    				tme "#include-string expected a file or URL" block
				    			]
				    			insert tail linked read find-file value
				    			block: value2
				    		]
							#include-binary = first block [
				    			set/any [value value2] do/next next block
				    			any [
				    				file? get/any 'value
				    				url? get/any 'value
				    				tme "#include-binary expected a file or URL" block
				    			]
				    			insert tail linked read/binary find-file value
				    			block: value2
				    		]
							true [
								insert/only tail linked first block
								block: next block
							]
						]
			    	]
			    	linked
			    ]
	
	            set [dir target] split-path file
	            ; prevent multiple includes
	            unless all [included?: find/only :included :target check] [
	            	found: find-file file
	                unless included? [insert tail :included :target]
	                set [result target] split-path found
	                ; remember the current dir and change it
	                dir: system/script/path
	                if file? result [change-dir result]
	                found: load/all found
	                if header [
		                unless parse found ['rebol block! to end] [
		                	throw make error! reform [
								"Include error, file" file "missing a header"
							]
		                ]
						either link [insert tail linked copy/part found 2] [
							system/script/header: make object! found/2
						]
					]
					if found/1 = 'rebol [found: skip found 2]
	                include-block linked found
	                result: linked
	                if all [header not link] [set/any 'result do linked]
					; return to the "original" dir
					system/script/path: dir
	                ; finish the job
	                if all [header link] [
			        	binary-base: system/options/binary-base
			        	system/options/binary-base: 64
						write output mold/only linked
						system/options/binary-base: binary-base
					]
					get/any 'result
	            ]
			]
	
	        included: either link [copy []] [included-files]
	        include-script/header copy [] file check link
	    ]
	    
	]
]
