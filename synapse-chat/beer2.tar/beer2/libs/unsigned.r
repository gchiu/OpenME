REBOL [
	Title: "Unsigned"
	File: %unsigned.r
	Date: 8-Oct-2005/13:17:46+2:00
	Purpose: {Unsigned integer arithmetic operators with wrapping}
	Author: ["Ladislav Mecir" "Jaime Vargas"]
]

; important constants
two-to-32: 4294967296.0

; the two functions below may be useful for input/output using decimal representation
uint32-to-number: func [n [integer!]] [either negative? n [n + two-to-32] [n]]

number-to-uint32: func [[catch] n [number!]] [
	if any [n < 0 n >= two-to-32] [throw make error! "Out of range"]
	to integer! either n <= max-int-32 [n] [n - two-to-32]
]

add-unsigned: func [
	{unsigned addition with wrapping}
	x [integer!]
	y [integer!]
] [
	first (to pair! x) + y
]
	
subtract-unsigned: func [
	{unsigned subtraction with wrapping}
	x [integer!]
	y [integer!]
] [
	first (to pair! x) - y
]
