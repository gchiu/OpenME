Rebol [
	Date: 2-Mar-2006/13:52:42+1:00
	Author: "Ladislav Mecir"
	Title: "timer.r"
]

use [alarms] [

	alarms: make list! 0
	
	add-alarm: func [
		time [date! time! number!]
		alarm [word! function!]
	] [
		if number? time [time: to time! time]
		if time? time [time: now/precise + time]
		alarms: tail alarms
		while [all [not head? alarms time < first first back alarms]] [
			alarms: back alarms
		]
		if head? alarms [
			either time? system/ports/wait-list/1 [
				system/ports/wait-list/1: difference time now/precise
			] [
				insert system/ports/wait-list difference time now/precise
			]
		]
		insert/only alarms reduce [time :alarm]
	]
	
	do-events: func [/on-error callback /local alarm err derr] [
		while [true] [
			while [
				alarms: head alarms
				all [not tail? alarms alarms/1/1 <= now/precise]
			] [
				alarm: alarms/1
				remove alarms
				do next alarm
			]
			either empty? alarms [
				if time? system/ports/wait-list/1 [
					remove system/ports/wait-list
				]
			] [
				either time? system/ports/wait-list/1 [
					system/ports/wait-list/1: difference alarms/1/1 now/precise
				] [
					insert system/ports/wait-list difference alarms/1/1 now/precise
				]
			]
			if error? err: try [wait []] [
				either on-error [callback err] [print mold disarm err]
			]
		]
	]
	
]
