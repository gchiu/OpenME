Rebol [
	Title: "filetransfer profile"
	Author: "Richard Smolak"
	Date: 29-May-2006/2:50:31+2:00
	License: {
Copyright (C) 2005 Why Wire, Inc.

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Other commercial licenses to this program are available from Why Wire, Inc.
}
]
query/clear system/words

register context [
	profile: 'filetransfer
	version: 1.0.0

	post-handler: none
	get-handler: none
	destination-dir: none
			
	; initial handler
	init: func [
		channel [object!]
	] [

;		print "ftINIT"
		
		channel/prof-data: make object! [
			; receiver state
			files-to-receive: aa/make 256
			file-ids: make block! []
			ans-0-rcv: copy ""
			
			; transmitter state
			files-to-transmit: make block! []
			ans-0-tr: copy #{}
			post-callbacks: make block! []
			post-cmds: make block! []

			ans-0-post: make block! []
			ans-0-postid: make block! []
			ch: channel
			id: cid: ansno: dr: file-port: ln: file: none

			;bind parsing rule block			
			rule: bind/copy command-rule 'self
			
			send-ans: none ; a function sending the appropriate ANS message
			payload-buffer: copy #{}
		]

		channel/read-msg: func [
			channel more payload /local prof-data port files sizes file rule
		] [
;			print "ftREADMSG"
;			probe more
;			probe payload
			
			prof-data: channel/prof-data

			insert tail prof-data/payload-buffer payload
			
			if more = "." [
				
				rule: prof-data/rule
				parse/all prof-data/payload-buffer [
					some [
						rule
					]
				]
				
				if not empty? prof-data/ans-0-tr [
					; multiple file transfer using ANS
;					print "SENDING ANS0"
;					probe to-string prof-data/ans-0-tr

					prof-data/send-ans: :send-ans-0
					send-reply channel func [channel] [
						channel/prof-data/send-ans channel
					]
				]
				
				if not empty? prof-data/ans-0-post [
					send-reply channel :write-NUL
					get-file/cid channel copy prof-data/ans-0-post post-handler copy prof-data/ans-0-postid
					
					clear prof-data/ans-0-post
					clear prof-data/ans-0-postid
				]
				clear prof-data/payload-buffer
			]
		]

		channel/close: func [
			{to let the profile know, that the channel is being closed}
			channel
		][
;			print "FT - chanel CLOSE"
			none
		]
	]

	send-ans-0: func [channel /local prof-data pl more size] [
		prof-data: channel/prof-data
		size: min channel/out-window MAXSIZE
		either size < length? prof-data/ans-0-tr [
			more: "*"
			pl: copy/part prof-data/ans-0-tr size
			prof-data/ans-0-tr: skip prof-data/ans-0-tr size
		] [
			more: "."
			pl: copy prof-data/ans-0-tr
			clear prof-data/ans-0-tr
			prof-data/send-ans: :send-files
		]
		write-ANS channel more 0 pl
	]

	send-files: func [
		channel
		/local
			size
			prof-data
			port
			ansnum
			payload
			file
			more
	] [
		; this transmits the contents of the files
		size: min channel/out-window MAXSIZE
		prof-data: channel/prof-data
		file: first prof-data/files-to-transmit
		; pick a port
		port: file/2
		ansnum: file/1
		
;			size: min size file/5
		
		payload: copy/part port size

;			file/5: file/5 - size

		; robin
		more: either all [payload not empty? payload][
;			more: either file/5 > 0 [			
			file/6: length? payload
			file/4 channel 'read file
			get-handler channel 'read file
			prof-data/files-to-transmit: next prof-data/files-to-transmit
			"*"
		] [
			file/6: 0
			file/4 channel 'write file
			get-handler channel 'write file
			payload: #{}
			if port? port [close port]
			remove prof-data/files-to-transmit
			"."
		]

		if binary? port [
		 	clear file/2
		]

		; round
		if tail? prof-data/files-to-transmit [prof-data/files-to-transmit: head prof-data/files-to-transmit]

		write-ANS channel more ansnum payload

		if empty? prof-data/files-to-transmit [
			prof-data/send-ans: none
			; write NUL frame after all files have been transmitted
			write-NUL channel
		]
	]


	make-id: does [
		enbase/base checksum/secure form random/secure to-integer #{7fffffff} 16
	]

	ft-reply: func [
		msg channel more ansno payload /local prof-data file rule
	] [
;		print [
;			"ft-profile received:" msg channel/chno more ansno mold either payload [length? payload][payload]
;		]
			prof-data: channel/prof-data

			either ansno = 0 [
;				print "RECEIVING ANS 0"

				; defragment the frame, 40'000 is an arbitrary limit
;				probe prof-data/ans-0-rcv: defragment in prof-data 'ans-0-rcv more payload 40'000 [
;					poorly-formed "ft-profile: too many files"
;				]

				insert tail prof-data/ans-0-rcv payload

				if more = "." [
					rule: prof-data/rule
					parse/all prof-data/ans-0-rcv [
						some [
							rule	
						]
					]
					clear prof-data/ans-0-rcv
				]
			] [
				if msg <> "NUL" [
;					print ["writing chunk" type? payload]
					file: aa/get channel/prof-data/files-to-receive select prof-data/file-ids ansno

					either more = "." [
						close file/2
						file/4 channel 'write file
						aa/remove channel/prof-data/files-to-receive file/1
						remove/part find prof-data/file-ids ansno 2
					][
						file/6: length? payload
						write-io file/2 payload file/6 
						file/4 channel 'read file
					]
				]
			]
	]

	set 'get-file func [
		{issues GET command on appropriate filetransfer channel}
		channel [object!]
		blk [block!]
		callback [block! none!]
		/dst-dir
			dst [file!]
		/cid
			callbacks [block!]
		/local
			cmd
			id
			prof-data
			callback-id
	][
		prof-data: channel/prof-data
		cmd: copy #{}
		if all [dst not exists? dst][
			make-dir dst
		]
		foreach f blk [
			until [
				not exists? join any [dst destination-dir] id: make-id
			]
			if cid [
				callback-id: pick callbacks index? find blk f
			]
			
			insert tail cmd rejoin ["get" f "*" id " cid" callback-id " "]

			aa/set prof-data/files-to-receive id reduce [
				id
				open/new/binary/direct join any [dst destination-dir] id
				f
				all [callback func [channel [object!] action [word!] data [block!]] callback]
				0
				0
				any [dst destination-dir]
				0
			]
		]
		if not empty? cmd [
			beer/send-MSG channel beer/pack-msg get in beer 'write-MSG cmd :ft-reply
		]
	]

	set 'post-file func [
		channel [object!]
		blk [block!]
		callback [block! none!]
		/local
		 cmd
		cid
		prof-data
	][
		prof-data: channel/prof-data
		cmd: copy #{}
		foreach f blk [
			cid: make-id
			insert tail prof-data/post-callbacks reduce [
				cid
				either callback [
					func [channel [object!] action [word!] data [block!]] callback
				][
					none
				]
			]
			insert tail cmd rejoin ["post" f "*" cid " "]
		]

		beer/send-MSG channel beer/pack-msg get in beer 'write-MSG cmd :ft-reply
	]

	command-rule: [
		"get" copy file to "*" skip copy id to " " skip "cid" copy cid to " " skip (
;			print ["Start sending" file]
			self/ansno: length? head files-to-transmit
			until [
				not find file-ids self/ansno: self/ansno + 1
			]
			either dir? file: to-file file [
				insert/only files-to-transmit file: reduce [
					self/ansno dr: to-binary mold/only read file file select post-callbacks cid 0 0
				]
				insert tail ans-0-tr rejoin [to-binary "init" id " " file/5: length? dr " " file/1 " "]
			][
				;ansno, port, filename, callback, total filesize, chunk size
				insert/only files-to-transmit file: reduce [
					self/ansno file-port: open/binary/direct/read file file select post-callbacks cid 0 0
				]
				insert tail ans-0-tr rejoin [to-binary "init" id " " file/5: file-port/size " " file/1 " "]
			]
			remove/part find post-callbacks cid 2
			file/4 ch 'init file
			get-handler ch 'init file
		)
		| "post" copy file to "*" skip copy id to " " skip (
;			print "POST"
			insert tail ans-0-post to-file file
			insert tail ans-0-postid to-file id
		)
		| "init" copy file to " " skip copy ln to " " skip copy ansno to " " skip (
;			print ["INIT" file-ids]
			insert tail file-ids reduce [to-integer ansno file]
			file: aa/get files-to-receive file
			file/5: to-integer ln
			file/4 ch 'init file
		)
	]
]
