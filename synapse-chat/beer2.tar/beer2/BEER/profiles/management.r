Rebol [
	Title: "BEER Channel Management"
	Date: 30-May-2006/10:37:01+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
	Purpose: {BEER Channel management profile definition}
]

; Low-level channel management
create-channel: func [
	[catch]
	session [object!]
	channel-number [integer!]
	profile-name
	/rights peer-rights
	/local channel
] [
	debug ["Creating channel" channel-number "using profile" profile-name]
	if aa/get session/channels channel-number [
		throw make error! "channel already exists"
	]
	if all [profile-name = 'channel-management channel-number <> 0] [
		throw make error! rejoin [
			"Channel management profile not allowed for channel " channel-number
		]
	]
	channel: make channel-data [
		unless profile: in profile-registry profile-name [
			throw make error! "Unsupported profile"
		]
		profile: get profile
		chno: channel-number
		out-msgs: make list! EXPUNREPLIED
		out-replies: make list! EXPUNREPLIED
		read-rpy: make list! EXPUNREPLIED
	]
	channel/session: session
	channel/rights: peer-rights
	aa/set session/channels channel-number channel
	channel/profile/init channel
	; debug "Channel created"
	channel
]

destroy-channel: func [
	[catch]
	channel
	/local session
] [
	session: channel/session
	aa/get/default session/channels channel/chno [
		throw make error! "Destroying nonexistent channel"
	]
	aa/remove session/channels channel/chno
	channel/out-msgs: make list! 0
	channel/out-replies: make list! 0
	channel/out-closing?: true
	channel/in-closing?: true
]

ack-in-no?: func [
	{The number of the last acknowledged incoming message}
	channel
] [
	either all [
		channel/out-type
		channel/out-type <> "MSG"
	] [
		channel/first-to-send
	] [
		msgno-add channel/first-to-send -1
	]
]

ack-out-no?: func [
	{The number of the last acknowledged outgoing message}
	channel
] [
	either all [
		channel/in-type
		channel/in-type <> "MSG"
	] [
		channel/first-to-receive
	] [
		msgno-add channel/first-to-receive -1
	]
]

last-in?: func [
	{The number of the last incoming MSG}
	channel
] [
	either channel/in-type = "MSG" [
		channel/in-msgno
	] [
		msgno-add channel/in-msgno -1
	]
]

last-out?: func [
	{The number of the last outgoing MSG}
	channel
] [
	either channel/out-type = "MSG" [
		channel/out-msgno
	] [
		msgno-add channel/out-msgno -1
	]
]

ack-in?: func [
	{Are all incoming MSG's in a non-management channel acknowledged?}
	channel
] [
	(last-in? channel) = (ack-in-no? channel)
]

ack-out?: func [
	{Are all sent MSG's in a non-management channel acknowledged?}
	channel
] [
	(last-out? channel) = (ack-out-no? channel)
]

defragment: func [
	{Defragment a message}
	[throw]
	fragment [word!]
	more [string!]
	payload [string!]
	limit [integer!]
	on-fail [block!]
] [
	insert tail get fragment payload
	
	if limit < length? get fragment on-fail ; limit exceeded
	
	if more = "*" [exit] ; wait for complete message
	
	payload: get fragment
	
	; reset defragmentation data 
	set fragment copy ""
	
	payload
]

; Maximal Channel management payload
MAXMGMT: 4'096

open-channel: none
close-channel: none

; Channel management profile definition
register context [
	profile: 'channel-management
	version: 1.0.0

	; initial handler
	init: func [
		channel [object!]
	] [
		
		debug "Channel management: initializing channel 0"

		; adjust the channel state for my own and peer's dummy MSG 0
		channel/out-msgno: 1 ; my MSG 0 was "dummy"	
		channel/in-msgno: 1 ; peer's MSG 0 was "dummy"
		
		; the initial reply handler
		insert tail channel/read-rpy :read-greeting

		channel/prof-data: make object! [
			; defragmentation variable
			fragment: copy ""
		]
		
		; the initial read-msg handler
		channel/read-msg: func [
			channel [object!]
			more [string!]
			payload [any-string!]
		] [
			poorly-formed "Peer unavailable"
		]

		; send greeting
		send-reply channel pack-msg :write-RPY mold/only [greeting]
	]

	read-greeting:  func [
		{read-reply handler for channel 0}
		msg channel more ansno payload
	] [
		if msg <> "RPY" [poorly-formed "Peer unavailable"]
		
		payload: defragment in channel/prof-data 'fragment more payload MAXMGMT [
			poorly-formed "management message limit exceeded"
		]

		either all [
			not error? try [payload: load/all payload]
			parse payload ['greeting]
		] [
			; greeting received, we can proceed further
			channel/read-msg: :read-further
			channel/session/on-open channel/session
		] [
			; peer unavailable
			poorly-formed "Peer unavailable"
		]
	]

	read-further: func [
		{Read-MSG handler for channel 0}
		[catch]
		channel
		more
		payload
		/local start chno profile-arg version-arg session prof-data peer-rights
		stop channel-arg err-frame
	] [
		start: [
			'start set chno number!
			'with-profile
			set profile-arg word!
			set version-arg tuple!
			(
				catch' [				
					if aa/get session/channels chno [
						send-reply channel pack-msg :write-ERR mold/only reduce [
							"Channel" chno "already exists"
						]
						throw'
					]
		
					unless registered? profile-arg version-arg [
						send-reply channel pack-msg :write-ERR mold/only reduce [
							"Unsupported profile: "
							profile-arg version-arg
						]
						throw'
					]
				
					if profile-arg = 'channel-management [
						send-reply channel pack-msg :write-ERR mold/only reduce [
							"Channel-management profile not allowed for channel"
							chno
						]
						throw'
					]
					
					peer-rights: aa/get/default session/rights profile-arg [
						send-reply channel pack-msg :write-ERR "Insufficient rights"
						throw'
					]

					if (even? chno) xor (session/role = 'I) [
						send-reply channel pack-msg :write-ERR mold/only reduce [
							"Wrong chno parity" chno
						]
						throw'
					]
					
					; create channel
					send-reply channel pack-msg/callback :write-RPY mold/only [
						ok
					] compose [
						create-channel/rights (channel/session) (chno) (to lit-word! profile-arg) peer-rights
					]
				]
			)
		]
		
		stop: ['stop set chno number! (
			catch' [
				channel-arg: aa/get/default session/channels chno [
					send-reply channel pack-msg :write-ERR rejoin [
						"Channel" chno "doesn't exist"
					]
					throw'
				]
				
				; discern channel and session close
				either chno <> 0 [
					; channel close variant
					if channel-arg/in-closing? [
						send-reply channel pack-msg :write-ERR rejoin [
							"Channel" chno "already closing"
						]
						throw'
					]
					
					unless ack-in? channel-arg [
						send-reply channel pack-msg :write-ERR {unacknowledged incoming MSG}
						throw'
					]
				
					; check whether the request should be refused
					if string? set/any 'err-frame channel-arg/close channel-arg [
						; refuse to close
						send-reply channel pack-msg :write-ERR err-frame
						throw'
					]

					debug ["channel" chno "close accepted"]
					channel-arg/in-closing?: true
					send-reply channel close-channel-ok session chno
					send-msg channel-arg :close-channel-lll does [
						make error! "not supposed to get here"
					]
				] [
					; session close variant
					if 1 < msgno-sub ack-in-no? channel last-in? channel [
						send-reply channel pack-msg :write-ERR {Channel 0: unacknowledged incoming MSG}
						throw'
					]

					; ask all channels
					; (except for already closing channels)
					foreach channel-arg next head session/channels/values [
						unless channel-arg/in-closing? [
							unless ack-in? channel-arg [
								send-reply channel pack-msg :write-ERR {unacknowledged incoming MSG}
								throw'
							]
							if string? set/any 'err-frame channel-arg/close/ask channel-arg [
								; request refused, done
								send-reply channel pack-msg :write-ERR err-frame
								throw'
							]
						]
					]

					debug "session close request accepted"
					; channel0 can be closed
					channel/in-closing?: true
					send-reply channel :close-session-ok
					; tell every channel
					; (except for already closing channels)
					foreach channel-arg next head session/channels/values [
						unless channel-arg/in-closing? [
							channel-arg/in-closing?: true
							if string? set/any 'err-frame channel-arg/close channel-arg [
								throw make error! rejoin [
									"Channel " channel-arg/chno " refused close"
								]
							]
							send-msg channel-arg :close-channel-lll does [
								make error! "not supposed to get here"
							]
						]
					]
				]
			]
		)]
	
		debug ["MSG:" mold payload]
		prof-data: channel/prof-data
		session: channel/session

		payload: defragment in channel/prof-data 'fragment more payload MAXMGMT [
			poorly-formed "management message limit exceeded"
		] 

		if any [
			error? try [payload: load/all payload]
			not parse payload [start | stop]
		] [
			poorly-formed "Unexpected channel management message"
		]
	]

	close-channel-ok: func [session chno] [
		do func [session chno] [
			func [
				{close channel ok reply handler for channel0}
				channel0
			] [
				aa/get/default session/channels chno [
					if channel0/out-window > 2 [
						write-RPY channel0 "." mold/only [ok]
					]
				]
			]
		] session chno
	]

	close-channel-lll: func [
		{channel is finishing its work, msg handler}
		channel
		/local channel0
	] [
		if all [
			; all replies sent?
			empty? head channel/out-replies
			; all replies received?
			channel/first-to-receive = channel/out-msgno
		] [
			channel0: aa/get channel/session/channels 0
			destroy-channel channel
			channel-send channel0
		]
	]

	close-session-ok: func [
		{close session reply handler for channel0}
		channel0
	] [
		if all [
			; all other channels closed?
			empty? channels: next head channel0/session/channels/values
			; all management messages sent?
			empty? channel0/out-msgs
			; all management replies received?
			; (except perhaps for session close request)
			any [
				channel0/first-to-receive = channel0/out-msgno
				all [
					channel0/out-closing?
					channel0/first-to-receive = msgno-add channel0/out-msgno -1
				]
			]
			channel0/out-window > 2
		] [
			write-RPY channel0 "." mold/only [ok] compose [
				destroy-session (channel0/session) "Closing session"
			]
		]
	]

	set 'open-channel func [
		[catch]
		session
		profile
		version
		callback
		/local channel0 channel-no profile-o
	] [
		unless in profile-registry profile [throw make error! "nonexistent profile"]
		if profile = 'channel-management [
			throw make error! "channel-management only at channel 0"
		]
		profile-o: profile-registry/:profile
		unless profile-o/version = version [throw make error! "incorrect version"]
		channel-no: session/free-chno
		until [
			session/free-chno: msgno-add session/free-chno 2
			not aa/get session/channels session/free-chno
		]
		channel0: aa/get session/channels 0
		if any [
			channel0/in-closing?
			channel0/out-closing?
		] [
			callback "session closing"
			exit
		]
		debug "Open channel"
		send-msg channel0 pack-msg :write-MSG mold/only reduce [
			'start channel-no 'with-profile profile version
		] do func [session channel-no profile version callback] [
			func [msg channel more ansno payload] [
				if any [msg = "ANS" msg = "NUL"] [
					poorly-formed [msg "not expected in the management channel"]
				]
				
				payload: defragment in channel/prof-data 'fragment more payload MAXMGMT [
					poorly-formed "management message limit exceeded"
				]
		
				either msg = "RPY" [
					either all [
						not error? try [payload: load/all payload]
						parse payload ['ok]
					] [
						callback create-channel session channel-no profile version
					] [
						poorly-formed "unexpected RPY in the management channel" 
					]
				] [
					; ERR message received
					callback payload
				]
			]
		] session channel-no profile version :callback

	]
	
	set 'close-channel func [
		{Close a channel/session}
		[catch]
		channel-to-close
		callback
		/local channel0 channels err-frame reply-handler
	] [
		channels: channel-to-close/session/channels
		channel0: aa/get channels 0
		if any [
			channel0/in-closing?
			channel0/out-closing?
		] [
			callback "session closing"
			exit
		]
		unless ack-out? channel-to-close [
			callback "unacknowledged MSGs exist"
			exit
		]
		reply-handler: either 0 <> channel-to-close/chno [
			; local channel close check
			if string? set/any 'err-frame channel-to-close/close channel-to-close [
				callback rejoin [
					"channel " channel-to-close/chno " already closing"
				]
				exit
			]
			do func [channel-to-close callback] [
				func [msg channel more ansno payload] [
					if any [msg = "ANS" msg = "NUL"] [
						poorly-formed [msg "not expected in the management channel"]
					]
					
					payload: defragment in channel/prof-data 'fragment more payload MAXMGMT [
						poorly-formed "management message limit exceeded"
					]
			
					either msg = "RPY" [
						either all [
							not error? try [payload: load/all payload]
							parse payload ['ok]
						] [
							destroy-channel channel-to-close
							callback true
						] [
							poorly-formed "unexpected RPY in the management channel" 
						]
					] [
						; ERR message received
						callback payload
					]
				]
			] channel-to-close :callback
		] [
			; check session close locally
			channels: next channels/values
			foreach channel-arg channels [
				unless any [
					channel-arg/in-closing?
					channel-arg/out-closing?
				] [
					unless ack-out? channel-arg [
						callback "unacknowledged MSGs exist"
						exit
					]
					if string? set/any 'err-frame channel-arg/close/ask channel-arg [
						callback err-frame
						exit
					]
				]
			]
			; session close OK locally
			foreach channel-arg channels [
				unless channel-arg/out-closing? [
					if err-frame: channel-arg/close channel-arg [
						throw make error! rejoin [
							"Channel " channel-arg/chno " refused close"
						]
					]
					channel-arg/out-closing?: true
				]
			]
			do func [callback] [
				func [msg channel more ansno payload] [
					if any [msg = "ANS" msg = "NUL"] [
						poorly-formed [msg "not expected in the management channel"]
					]
					
					payload: defragment in channel/prof-data 'fragment more payload MAXMGMT [
						poorly-formed "management message limit exceeded"
					]
			
					either msg = "RPY" [
						either all [
							not error? try [payload: load/all payload]
							parse payload ['ok]
						] [
							destroy-session channel/session "Closing session" 
							callback true
						] [
							poorly-formed "unexpected RPY in the management channel" 
						]
					] [
						; ERR message received
						callback payload
					]
				]
			] :callback
		]
		channel-to-close/out-closing?: true
		send-msg channel0 pack-msg :write-MSG mold/only reduce [
			'stop channel-to-close/chno
		] :reply-handler
	]

]
