Rebol [
	Title: "BEER profile registry"
	File: "%profiles.r"
	Date: 15-Mar-2006/10:32:42+1:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

profile-registry: make object! [] ; the profile registry, starting as empty

register: func [profile-o [object!]][
	profile-registry: make profile-registry compose [
		(to set-word! profile-o/profile) profile-o
	]
]

registered?: func [profile [word!] version [tuple!]][
	all [
		in profile-registry profile
		profile-registry/:profile/version = version
	]
]
