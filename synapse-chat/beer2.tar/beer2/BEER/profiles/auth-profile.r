Rebol [
	Title: "BEER Auth profile"
	Date: 24-May-2006/17:04:31+2:00
	Author: "Ladislav Mecir"
	Purpose: {BEER authentication profile}
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

login: none

register context [
	profile: 'auth
	version: 1.0.0

	; initial handler
	init: func [channel [object!]] [
		debug ["Auth profile: initializing channel" channel/chno]
		channel/prof-data: make object! [
			; to keep track of the MSG fragments
			fragment: copy ""
			; to keep track of the challenge
			challenge: none
			; to keep track of the login request
			username: none
			password: none
			with: none
			callback: none
		]
		channel/read-msg: func [
			channel more payload
			/local login answer response prof-data session
		] [
            debug ["auth profile:" "MSG" more mold payload]
            prof-data: channel/prof-data
            ; defragment the message, set limit to 1'000
			payload: defragment in prof-data 'fragment more payload 1'000 [
				poorly-formed "Auth MSG limit exceeded"
			]

            session: channel/session
			login: ['login (
				catch' [
					if prof-data/challenge [
						; peer tries login after receiving a challenge
						poorly-formed "Challenge already sent"
					]
					
					prof-data/challenge: make-challenge encoding-salt
					send-reply channel pack-msg :write-RPY mold/only head insert tail copy [
						challenge
					] prof-data/challenge
				]
			)]
		
			answer: ['answer set response binary! (
				catch' [
					unless prof-data/challenge [
						; peer is sending an answer without receiving a challenge
						poorly-formed "Challenge not sent"
					]
					unless response: verify-challenge users prof-data/challenge response [
						poorly-formed "Login incorrect"
					]
					session/username: response/1
					session/key: response/2
					session/rights: rights? session/username
					debug ["user" session/username "logged in"]
					
					send-reply channel pack-msg :write-RPY mold/only [ok]
				]
			)]
			
			if any [
				error? try [payload: load/all to string! payload]
				not parse payload [login | answer]
			] [
				poorly-formed "Unexpected message in Auth channel"
			]

		]
		; close handler
		channel/close: func [channel /ask] [
			either ask [debug "channel close asked"] [
				debug "channel close processing"
			]
			; any other value than a string agrees with close
			; a string would be used as an ERR message payload
			none
		]
	]

	login-reply: func [
		{this is how a login reply can be processed}
		msg channel more ansno payload
		/local prof-data challenge encoding-salt salt
	] [
		debug ["Auth profile, login reply:" msg more ansno mold payload]
		if msg <> "RPY" [poorly-formed "Auth profile: RPY reply expected"]
		prof-data: channel/prof-data
	    ; defragment the message, set limit to 1'000
		payload: defragment in prof-data 'fragment more payload 1'000 [
			poorly-formed "Auth MSG limit exceeded"
		]
		challenge: ['challenge set encoding-salt binary! set salt binary! (
			encoding-salt: either prof-data/with [prof-data/password] [
				encode-pass prof-data/password encoding-salt
			]
			send-msg channel pack-msg :write-MSG mold/only append copy [
				answer
			] answer-challenge prof-data/username encoding-salt salt :answer-reply
		)]
		
		if any [
			error? try [payload: load/all to string! payload]
			not parse payload challenge
		] [
			poorly-formed "Unexpected challenge in Auth channel"
		]
	]

	answer-reply: func [
		{this is how an answer reply can be processed}
		msg channel more ansno payload
		/local prof-data ok
	] [
		debug ["Auth profile, login reply:" msg more ansno mold payload]
		if msg <> "RPY" [poorly-formed "Auth profile: RPY reply expected"]
		prof-data: channel/prof-data
	    ; defragment the message, set limit to 1'000
		payload: defragment in prof-data 'fragment more payload 1'000 [
			poorly-formed "Auth MSG limit exceeded"
		]
		ok: ['ok (
			debug ["login successful"]
			prof-data/callback true
		)]
		
		if any [
			error? try [payload: load/all to string! payload]
			not parse payload ok
		] [
			poorly-formed "Unexpected answer-reply in Auth channel"
		]
	]

	set 'login func [
		[catch]
		channel [object!]
		user [string!]
		pass [string! binary!]
		callback [function!]
		/with {pass is encoded}
		/local prof-data
	] [
		unless (string? pass) xor with [throw make error! "wrong password type"]
		debug "Login"
		prof-data: channel/prof-data
		prof-data/username: user
		prof-data/password: pass
		prof-data/with: with
		prof-data/callback: :callback
		send-msg channel pack-msg :write-MSG mold/only [login] :login-reply
	]

]
