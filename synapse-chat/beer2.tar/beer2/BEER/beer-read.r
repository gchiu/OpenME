Rebol [
	Title: "BEER read"
	File: %beer-read.r
	Date: 21-Jun-2006/17:39:12+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

digit: charset [#"0" - #"9"]

session-read: func [
	session [object!]
	data [binary!]
	/local processed
	size-rule common-rule payload-rule
	channel-check seqno-check fragment-check reply-check
	seq-rule msg-rule rpy-err-rule ans-rule nul-rule
	poorly-formed read-rpy
	msg channel msgno more seqno size payload
	shift
] [
	channel-check: does [
		if error? try [channel: to integer! channel] [
			poorly-formed session ["invalid chno" processed]
		]
		channel: aa/get/default session/channels channel [
			poorly-formed session ["Channel" channel "non existent" processed]
		]
	]

	seqno-check: does [
		if error? try [
			seqno: to decimal! seqno
			seqno: to integer! either seqno < two-to-31 [seqno] [
				seqno - two-to-32
			]
		] [poorly-formed session ["invalid seqno" processed]]
	]
	
	size-rule: [
		copy size 1 10 digit (
			if error? try [size: to integer! size] [
				poorly-formed session ["invalid size" processed]
			]
		)
	]
	
	seq-rule: [
		"SEQ "
		copy channel 1 10 digit " "
		copy seqno 1 10 digit " "
		size-rule "^M^/" (
			channel-check
			seqno-check
			if 0 > shift: subtract-unsigned channel/out-seqno seqno [
				poorly-formed session [
					"Sync lost. Maximal seqno" channel/out-seqno
					"received" seqno
				]
			]
			size: size - shift
			if size <= channel/out-window [
				poorly-formed session "SEQ frame trying to shrink the window"
			]
			; update output window
			channel/out-window: size
			; we may be able to send something
			channel-send channel
		)
	]
	
	common-rule: [
		" " copy channel 1 10 digit
		" " copy msgno 1 10 digit
		" " copy more ["." | "*"]
		" " copy seqno 1 10 digit
		" " size-rule
	]
	
	fragment-check: does [
		; check whether the frame is allowed
		if all [channel/in-type channel/in-type <> msg] [
			poorly-formed session [
				channel/in-type "fragment expected," msg "received"
			]
		]
		; adjust in-type
		if more = "*" [channel/in-type: msg]
	]

	payload-rule: [
		"^M^/" copy payload size skip "END^M^/" (
			channel-check
			if error? try [msgno: to integer! msgno] [
				poorly-formed session ["invalid msgno" processed]
			]
			seqno-check
			if seqno <> channel/in-seqno [
				poorly-formed session [
					"Sync lost. Expected seqno" channel/in-seqno
					"received" seqno
				]
			]
			; adjust in-window
			channel/in-window: channel/in-window - size
			; check in-window
			if channel/in-window < 0 [
				poorly-formed session [
					"channel:" channel/chno
					"input window exceeded by"
					negate channel/in-window
				]
			]
			; adjust seqno
			channel/in-seqno: add-unsigned channel/in-seqno size
		)
	]

	msg-rule: [
		copy msg "MSG" common-rule payload-rule (
			if channel/in-closing? [
				poorly-formed [
					"Channel" channel/chno "closing, MSG not allowed"
				]
			]
			; check msgno
			if msgno <> channel/in-msgno [
				poorly-formed session [
					"expected msgno" channel/in-msgno
					"received msgno" msgno
				]
			]
			fragment-check
			; adjust in-msgno and in-type
			if more = "." [
				channel/in-msgno: msgno-add channel/in-msgno 1
				channel/in-type: none
			]
			channel/read-msg channel more payload
			send-seq channel
		)
	]
	
	reply-check: does [
		if msgno <> channel/first-to-receive [
			poorly-formed session [
				"expected reply msgno" channel/first-to-receive
				"received" msgno
			]
		]
		unless any [
			positive? msgno-sub channel/out-msgno msgno
			all [ 
				channel/out-type = "MSG"
				msgno = channel/out-msgno
			]
		] [poorly-formed session ["reply unexpected"]]
	]
	
	rpy-err-rule: [
		copy msg ["RPY" | "ERR"] common-rule payload-rule (
			reply-check
			fragment-check
			; adjust first-to-receive
			if more = "." [
				channel/first-to-receive: msgno-add channel/first-to-receive 1
				channel/in-type: none
			]
			read-rpy: first head channel/read-rpy
			read-rpy msg channel more none payload
			if more = "." [channel/read-rpy: remove head channel/read-rpy] 
			send-seq channel
		)
	]
	
	ans-rule: [
		copy msg "ANS" common-rule " " copy ansno 1 10 digit payload-rule (
			if error? try [ansno: to integer! ansno] [
				poorly-formed session ["invalid ansno" processed]
			]
			reply-check
			; check whether the frame is allowed
			if all [
				channel/in-type
				not find ["ANS" "NUL"] channel/in-type
			] [
				poorly-formed session [
					channel/in-type "fragment expected," msg "received"
				]
			]
			; adjust in-type
			channel/in-type: either more = "*" ["ANS"] ["NUL"]
			read-rpy: first head channel/read-rpy
			read-rpy msg channel more ansno payload
			send-seq channel
		)
	]
	
	nul-rule: [
		copy msg "NUL" 
		" " copy channel 1 10 digit
		" " copy msgno 1 10 digit
		" " copy more "."
		" " copy seqno 1 10 digit
		" 0" (size: 0)
		payload-rule (
			reply-check
			fragment-check
			channel/first-to-receive: msgno-add channel/first-to-receive 1
			channel/in-type: none
			read-rpy: first head channel/read-rpy
			read-rpy msg channel "." none none
			channel/read-rpy: remove head channel/read-rpy 
		)
	]
	
	insert tail session/buffer data

	catch' [
		poorly-formed: func [
			session [object!]
			reason
		] [
			destroy-session session reason
			throw' false
		]
		
		parse/all session/buffer [
			any [
				processed:
				seq-rule | msg-rule | rpy-err-rule | ans-rule | nul-rule
			]
		]
		if	MAXFRAME < length? processed [
			poorly-formed session ["frame too long" processed]
		]
	]
	remove/part session/buffer processed
]
