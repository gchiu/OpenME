Rebol [
	Title: "BEER Protocol Sending"
	Date: 30-May-2006/8:45+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

form-seqno: func [seqno [integer!]] [
	either negative? seqno [
		seqno: form seqno + two-to-32
		head clear find seqno #"."
	] [form seqno]
]

send-seq: func [
	{Send a seq frame, if useful}
	channel
	/local shift
] [
	shift: MAXBUFLEN - channel/in-window
	if WIN-SHIFT <= shift [
		channel/in-window: MAXBUFLEN
		beer-write channel/session rejoin [
			#{} "SEQ " channel/chno " " form-seqno channel/in-seqno " "
			MAXBUFLEN "^M^/"
		]
	]
]

write-MSG: func [
	[catch]
	channel [object!]
	more [string!]
	payload [any-string!]
] [
	unless channel/msg? [throw make error! "MSG fragment not requested"]
	if (min channel/out-window MAXSIZE) < length? payload [
		throw make error! "payload too long"
	]
	beer-write channel/session rejoin [
		#{} "MSG " channel/chno " " channel/out-msgno " " more " "
		form-seqno channel/out-seqno " " length? payload
		"^M^/" payload "END^M^/"
	]
	channel/out-type: either more = "."  [
		channel/out-msgno: msgno-add channel/out-msgno 1
		remove head channel/out-msgs
		none
	] ["MSG"]
	channel/out-seqno: add-unsigned channel/out-seqno length? payload
	channel/out-window: channel/out-window - length? payload
	channel/sent?: true
]

write-RPY: func [
	[catch]
	channel [object!]
	more [string!]
	payload [any-string!]
] [
	unless channel/reply? [throw make error! "reply fragment not requested"]
	if all [
		channel/out-type
		channel/out-type <> "RPY"
	] [throw make error! "RPY not expected"]
	if (min channel/out-window MAXSIZE) < length? payload [
		throw make error! "payload too long"
	]
	beer-write channel/session rejoin [
		#{} "RPY " channel/chno " " channel/first-to-send " " more " "
		form-seqno channel/out-seqno " " length? payload
		"^M^/" payload "END^M^/"
	]
	channel/out-type: either more = "."  [
		channel/first-to-send: msgno-add channel/first-to-send 1
		remove head channel/out-replies
		none
	] ["RPY"]
	channel/out-seqno: add-unsigned channel/out-seqno length? payload
	channel/out-window: channel/out-window - length? payload
	channel/sent?: true
]

write-ERR: func [
	[catch]
	channel [object!]
	more [string!]
	payload [any-string!]
] [
	unless channel/reply? [throw make error! "reply fragment not requested"]
	if all [
		channel/out-type
		channel/out-type <> "ERR"
	] [throw make error! "ERR not expected"]
	if (min channel/out-window MAXSIZE) < length? payload [
		throw make error! "payload too long"
	]
	beer-write channel/session rejoin [
		#{} "ERR " channel/chno " " channel/first-to-send " " more " "
		form-seqno channel/out-seqno " " length? payload
		"^M^/" payload "END^M^/"
	]
	channel/out-type: either more = "."  [
		channel/first-to-send: msgno-add channel/first-to-send 1
		remove head channel/out-replies
		none
	] ["ERR"]
	channel/out-seqno: add-unsigned channel/out-seqno length? payload
	channel/out-window: channel/out-window - length? payload
	channel/sent?: true
]

write-ANS: func [
	[catch]
	channel [object!]
	more [string!]
	ansno [integer!]
	payload [any-string!]
] [
	unless channel/reply? [throw make error! "reply fragment not requested"]
	if all [
		channel/out-type
		channel/out-type <> "NUL"
		channel/out-type <> "ANS"
	] [throw make error! "ANS not expected"]
	if (min channel/out-window MAXSIZE) < length? payload [
		throw make error! "payload too long"
	]
	beer-write channel/session rejoin [
		#{} "ANS " channel/chno " " channel/first-to-send " " more " "
		form-seqno channel/out-seqno " " length? payload " " ansno
		"^M^/" payload "END^M^/"
	]
	channel/out-type: either more = "."  ["NUL"] ["ANS"]
	channel/out-seqno: add-unsigned channel/out-seqno length? payload
	channel/out-window: channel/out-window - length? payload
	channel/sent?: true
]

write-NUL: func [
	[catch]
	channel [object!]
] [
	unless channel/reply? [throw make error! "reply fragment not requested"]
	if all [
		channel/out-type
		channel/out-type <> "NUL"
	] [throw make error! "NUL not expected"]
	beer-write channel/session rejoin [
		#{} "NUL " channel/chno " " channel/first-to-send " . "
		form-seqno channel/out-seqno " 0^M^/END^M^/"
	]
	channel/first-to-send: msgno-add channel/first-to-send 1
	remove head channel/out-replies
	channel/out-type: none
	channel/sent?: true
]

channel-send: func [
	channel [object!]
	/local msg check? leave
] [
	if channel/send? [exit]
	channel/send?: true
	leave: [
		channel/send?: false
		exit
	]
	check?: true
	channel/sent?: false
	while [channel/out-window > 0] [
		case [
			; can send a MSG?
			all [
				msg: pick head channel/out-msgs 1
				any [
					channel/out-type = "MSG"
					empty? head channel/out-replies 
					all [
						channel/out-type = none
						channel/fair? 
					]
				]
			] [
				channel/fair?: false
				channel/msg?: true
				msg channel
				channel/msg?: false
			]
			; can send a reply?
			msg: pick head channel/out-replies 1 [
				channel/fair?: true
				channel/reply?: true
				msg channel
				channel/reply?: false
			]
			; nothing to send
			true leave
		]
		if check?: not check? [
			unless channel/sent? leave
			channel/sent?: false
		]
	]
	do leave
]

pack-msg: func [
	[catch]
	write-msg [function!]
	payload [any-string!]
	/callback call-back [any-function! block!]
] [
	do func [write-msg payload callback] [
		func [channel [object!] /local more pl cb size] [
			size: min channel/out-window MAXSIZE
			either size < length? payload [
				more: "*"
				pl: copy/part payload size
				payload: skip payload size
				cb: none
			] [
				more: "."
				pl: payload
				cb: :callback
			]
			write-msg channel more pl
			cb
		]
	] :write-msg payload either block? :call-back [does call-back] [:call-back]
]

send-MSG: func [
	channel [object!]
	msg [any-function!]
	reply-handler [any-function!]
] [
	insert tail channel/read-rpy :reply-handler
	insert tail channel/out-msgs :msg
	channel-send channel
]

send-reply: func [
	channel [object!]
	reply [any-function!]
] [
	insert tail channel/out-replies :reply
	channel-send channel
]

beer-write: func [
	session [object!]
	frame [binary!]
] [
	insert session/port frame
]
