Rebol [
	Title: "BEER Protocol Data"
	Date: 7-Apr-2006/14:53:50+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

EXPPROFILES: 50 ; expected number of profiles

; number of currently open sessions
sessions: 0

; maximum currently open sessions
MAXSESSIONS: 5

two-to-31: 2'147'483'648.0

MIN-INT: to integer! #80000000

; msgno arithmetic

msgno-add: func [
	{Add an integer and a msgno yielding a msgno}
	number1
	number2
	/local sum
] [
	either 0 > sum: first (to pair! number1) + number2 [
		sum - MIN-INT
	] [sum]
]

MIN-DIF: to integer! #C0000000
MAX-DIF: to integer! #40000000

msgno-sub: func [
	msgno1
	msgno2
	/local dif
] [
	either MIN-DIF > dif: msgno1 - msgno2 [dif - MIN-INT] [
		either MAX-DIF <= dif [dif + MIN-INT] [dif]
	]
]

; the maximum number of bytes a peer can send without receiving a SEQ
; the first value below is the minimum as well as the initial value specified
; by rfc3081, the second value is used after the first SEQ frame comes
INITBUFLEN: 4'096
MAXBUFLEN: 8'192

; maximum current channels per session
; the value below is the minimum required by rfc3080
MAXCURCHAN: 257

; maximum size of TCP and IP headers
MAXTCPIP: 120

; maximum size of frame's header plus trailer
MAXHT: 61

; maximum size of a frame
; according to rfc3081 the size of a frame should be
; maximally 2 / 3 of the TCP's negotiated maximum segment size
MAXFRAME: to integer! 2 / 3 * 1'460

; maximum payload size
MAXSIZE: MAXFRAME - MAXHT

MAXSEQFRAME: 38 ; maximum length of a SEQ frame

; limit for sending a SEQ message, according to rfc3081 this value should be
; a half of MAXBUFLEN
WIN-SHIFT: to integer! MAXBUFLEN / 2

EXPCURCHAN: 10 ; expected values number of currently open channels
EXPUNREPLIED: 20 ; expected number of unreplied messages

channel-data: make object! [
	
	session: none
	
	chno: none ; channel number
	profile: none ; the profile object
	prof-data: none ; profile data
	rights: none ; peer rights
	
	; output state
	out-closing?: false
	out-msgno: 0 ; number of expected outgoing MSG
	out-type: none ; type of expected outgoing fragment
	first-to-send: 0 ; first reply number to send
	fair?: true ; "fair reply policy" switch
	sent?: false ; transmission indicator
	msg?: false ; msg fragment requested?
	reply?: false ; reply fragment requested?
	send?: false ; channel send requested?
	out-seqno: 0
	out-window: INITBUFLEN
	
	; input state
	in-closing?: false
	in-msgno: 0 ; number of expected incoming MSG
	in-type: none ; type of expected incoming fragment
	first-to-receive: 0 ; first reply number to receive
	in-seqno: 0
	in-window: INITBUFLEN
	
	; transmitted data
	out-msgs: none ; msg's waiting to be sent
	out-replies: none ; replies waiting to be sent
	
	; dynamic handlers
	read-msg: none ; MSG handler
	close: none ; close handler
	read-rpy: none ; reply handler FIFO
]

session-data: context [
	session-type: 'BEER
	role: none ; (either 'I for Initiator or 'L for Listener)
	channels: none ; aa/make MAXCURCHAN ; keys are channel numbers
	free-chno: none ; a channel number to use next
	buffer: none ; the session input buffer
	username: "anonymous"
	key: none
	rights: none ; peer rights
	; flow control variables
	on-open: none ; session open callback
	on-close: none ; session close callback
	open?: false
	remote-ip: none
	remote-port: none
	port: none
]
