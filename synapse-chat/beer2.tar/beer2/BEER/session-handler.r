Rebol [
	Title: "BEER Session Handler"
	Date: 21-Apr-2006/8:49:10+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

debug: :print;:none
log-error: none;:print

destroy-session: func [session msg /wait /local port callback] [
	port: session/port
	if session/open? [
		session/open?: false
		log-error msg
		sessions: sessions - 1
		either wait [close-iatcp/wait port] [close-iatcp port]
		callback: get in session 'on-close
		callback form reduce msg
	]
]

session-handler-proto: make atcp-handler-proto [
	session: none
	
	error: does [destroy-session session "Error event"]
    dns-failure: does [destroy-session session "DNS failure"]
    dns: does [
		debug [
			"dns success:" session/port/host ":" session/port/sub-port/port-id
		]
    ]
    max-retry: does [destroy-session session "Can't connect to listener"]
    connect: does [
		sessions: sessions + 1
		create-channel session 0 'channel-management
    ]
    read: does [session-read session copy port]
    write: none
    close: does [
		debug stats
		destroy-session session "Peer closed the connection."
    ]
	unknown: func [event] [       
        destroy-session session [
			"Unexpected event" event "should not happen"
		]
    ]
]
