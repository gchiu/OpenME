Rebol [
	Title: "BEER Listener Handler"
	Date: 21-Apr-2006/8:49:10+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

listener-handler: func [
	{BEER listener handler}
	port
	/local peer
] [
    
    #if [all [value? 'spfix spfix]] [
		if port/locals/flag [
			;false-awake-event
			return port/locals/flag: false
	    ]
	]
	     
	unless error? try [peer: pick port 1] [
		debug ["Initiator" peer/remote-ip "connected"]
		peer: open/custom make port! [scheme: 'atcp sub-port: peer] reduce [
			'handler make session-handler-proto [] 'transfer-size MAXBUFLEN
		]     
		set-modes peer [binary: true lines: false]
		peer/user-data: make session-data [
			role: 'L
			buffer: make string! MAXBUFLEN
			; associative array, keys are channel numbers
			channels: aa/make EXPCURCHAN
			free-chno: 2
			rights: rights? username
			open?: true
			remote-ip: peer/sub-port/remote-ip
			remote-port: peer/sub-port/remote-port
			port: peer
		]
		peer/user-data/on-open: peer/user-data/on-close: get in port 'on-open
		peer/locals/handler/port: peer
		peer/locals/handler/session: peer/user-data
		sessions: sessions + 1
		create-channel peer/user-data 0 'channel-management
		wait-start peer
	]
    false
]

open-listener: func [
	beer-port-id [integer!]
	/callback call-back [function!]
	/local listener
] [
	listener: open/binary/direct/no-wait [
		scheme: 'TCP
		port-id: beer-port-id
	]
	listener/user-data: make object! [on-open: :call-back]
	
	#if [all [value? 'spfix spfix]] [
		listener/locals: make object! [flag: false]
	]
	
	listener/awake: :listener-handler
	wait-start listener
	listener
]
