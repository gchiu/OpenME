Rebol [
	Title: "BEER Initiator"
	Date: 21-Apr-2006/16:24:26+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

open-session: func [
	url [url! block!]
	callback [function!]
	/timeout t [time!]
	/local peer
] [
	; default timeout is 3 seconds
	t: any [t 0:0:3]
	if url? url [
		peer: make object! [
			host: port-id: target: user: pass: path: timeout: none
		]
		net-utils/url-parser/parse-url peer url
		url: third peer
	]
	insert tail url [scheme: 'ATCP timeout: t]
	peer: open/binary/direct/custom url reduce [
		'handler make session-handler-proto [] 'transfer-size MAXBUFLEN
	]
	peer/user-data: make session-data [
		role: 'I
		buffer: make string! MAXBUFLEN
		channels: aa/make MAXCURCHAN ; keys are channel numbers
		free-chno: 1
		rights: rights? username
		on-open: :callback
		on-close: :callback
		open?: true
		remote-ip: peer/sub-port/remote-ip
		remote-port: peer/sub-port/remote-ip
		port: peer
	]
	peer/locals/max-retry: 1
	peer/locals/handler/port: peer
	peer/locals/handler/session: peer/user-data
	wait-start peer
]
