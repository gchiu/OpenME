Rebol [
	Title: "BEER close profile initiator example"
	Date: 30-May-2006/11:26:30+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

#do [
	do %../../paths.r
	[]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

; "runaway locals test"
[
	filetransfer rpc admin close-test monitor anonymous netmask broadcast
	dest-addr nologin initializer callback payload common-rule payload-rule
	read-RPY sink auth
]
query/clear system/words

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %initiator.r
	#include %profiles.r
	#include %management.r
	#include %close-test-profile.r
]

beer/open-session atcp://127.0.0.1:8000 func [session] [
	if object? session [
		peer: session
		print ["Connected to listener:" peer/port/sub-port/remote-ip]
		;session-done
		open-cl
	]
]

open-cl: does [
	beer/open-channel peer 'close-test 1.0.0 func [channel] [
		either object? channel [
			cl: channel
			print "Close test channel open"

			beer/send-msg channel beer/pack-msg get in beer 'write-MSG mold/only [ask-me] func [
				msg channel more ansno payload /local prof-data
			] [
				prof-data: channel/prof-data
				print [
					"close test, reply frame:"
					msg channel/chno more ansno mold payload
				]
				
				if msg <> "RPY" [poorly-formed "close test: RPY reply expected"]
				
				payload: beer/defragment in prof-data 'fragment more payload 4'000 [
					poorly-formed "close test: reply too long"
				]
				
				; RPY arrived, processing
				unless all [
					not error? try [payload: load/all payload]
					parse payload ['ask-ok]
				] [
					poorly-formed "close test: unexpected reply"
				]
			]

		] [print ["didn't succeed to open close test channel:" channel]]
	]
]

do-events
