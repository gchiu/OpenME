Rebol [
	Title: "BEER close-test Profile"
	Date: 4-May-2006/15:51:26+2:00
	Author: "Ladislav Mecir"
	Purpose: {An example/test profile}
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

; close-test profile
register context [
	profile: 'close-test
	version: 1.0.0

	; initial handler
	init: func [
		channel [object!]
		/local info
	] [
		debug ["Close-test: initializing channel" channel/chno]
		channel/prof-data: make object! [
			fragment: copy ""
			oc: func [arg] [print ["channel closed"]]
		]
		channel/read-msg: func [channel more payload /local prof-data] [
            payload: to string! payload
            debug ["close test:" "MSG" more mold payload]
            
			prof-data: channel/prof-data

			if any [
				error? try [
					payload: load/all payload
				]
				not parse payload [
					'ask-me (
						print "close test: replying ASK-ME"						
						send-reply channel pack-msg :write-RPY mold/only [ask-ok]
						send-msg channel pack-msg :write-MSG mold/only [
							asking
						] :close-reply
					) | 'asking (						
						send-reply channel pack-msg :write-RPY mold/only [
							close-me
						]
					)
				]
			] [
				send-reply channel pack-msg :write-ERR "Unexpected message"
			]
		]
		; close handler
		channel/close: func [channel /ask] [
			either ask [debug "channel close asked"] [
				debug "channel close processing"
			]
			none
		]
	]
	close-reply: func [
		msg channel more ansno payload /local prof-data
	] [
		prof-data: channel/prof-data
		debug ["close test, reply:" msg more ansno mold payload]
		
		if msg <> "RPY" [poorly-formed "close test: RPY reply expected"]
		
		payload: defragment in prof-data 'fragment more payload 4'000 [
			poorly-formed "close test: reply too long"
		]
		
		; RPY arrived, processing
		unless all [
			not error? try [payload: load/all payload]
			parse payload [
				'close-me (close-channel channel get in prof-data 'oc)
			]
		] [
			poorly-formed "close test: unexpected reply"
		]
	]
]
