root [
	echo []
	filetransfer []
	lns []
]

admin [
	echo []
	close-test []
]

monitor [
	echo []
	filetransfer []
	lns []
]

anonymous [
	echo []
	close-test []
	sink []
	speed []
	auth []
	lns []
]
