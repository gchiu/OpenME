Rebol [
	Title: "BEER Sink profile"
	Date: 10-May-2006/17:41:37+2:00
	Author: "Ladislav Mecir"
	Purpose: {
		An example/test profile
		For every MSG received the Sink profile sends a NUL reply
	}
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

sink-reply: none

register context [
	profile: 'sink
	version: 1.0.0

	; initial handler
	init: func [channel [object!]] [
		debug ["Sink profile: initializing channel" channel/chno]
		channel/prof-data: make object! [
			; to keep track of the MSG fragments
			fragment: none
		]
		channel/read-msg: func [channel more payload] [
            debug ["sink profile:" "MSG" more mold payload]
			unless channel/prof-data/fragment [
				; send the NUL reply
				send-reply channel :write-NUL
				channel/prof-data/fragment: more = "*"
			]
		]
		; close handler
		channel/close: func [channel /ask] [
			either ask [debug "channel close asked"] [
				debug "channel close processing"
			]
			; any other value than a string agrees with close
			; a string would be used as an ERR message payload
			none
		]
	]
	set 'sink-reply func [
		{this is how a Sink reply can be processed}
		msg channel more ansno payload
	] [
		debug ["sink profile, reply:" msg more ansno mold payload]
		if msg <> "NUL" [poorly-formed "sink profile: NUL reply expected"]	
	]
]
