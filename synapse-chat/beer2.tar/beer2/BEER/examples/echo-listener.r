Rebol [
	Title: "BEER Sink Listener Example"
	Date: 3-May-2006/9:07:17+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

#do [
	do %../../paths.r
	[]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %listener.r
	#include %profiles.r
	#include %management.r
	#include %echo-profile.r
]

beer/open-listener 8000

print "echo listener's up!"
do-events
