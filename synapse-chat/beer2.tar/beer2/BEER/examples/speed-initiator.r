Rebol [
	Title: "BEER Speed Initiator Example"
	Date: 10-May-2006/10:15:01+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

#do [
	do %../../paths.r
	[]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %initiator.r
	#include %profiles.r
	#include %management.r
	#include %speed-profile.r
]

testfiles: either empty? testfiles: ask "test files directory: (%/c/stazeno/AVSDC/):" [
	%/c/stazeno/AVSDC/
] [dirize load testfiles]

beer/open-session atcp://127.0.0.1:8000 func [session] [
	either object? session [
		peer: session
		print ["Connected to listener:" peer/port/sub-port/remote-ip]
		open-ec
	] [print session]
]

open-ec: does [
	beer/open-channel peer 'speed 1.0.0 func [channel] [
		either channel [
			ec: channel
			print "Channel ec open"
			file-transport
		] [print "didn't succeed to open first speed channel"]
	]
]

open-ec2: does [
	beer/open-channel peer 'speed 1.0.0 func [channel] [
		either channel [
			ec2: channel
			print "channel ec2 open"
			file-transport
		] [print "didn't succeed to open second speed channel"]
	]
]

file-transport: does [
	if ec [
		print "file transport through ec"
		beer/send-MSG ec beer/pack-msg get in beer 'write-MSG "get" get in beer 'speed-reply
	]
	comment [
	if ec2 [
		print "file transport through ec2"
		beer/send-MSG ec beer/pack-msg get in beer 'write-MSG "get" get in beer 'speed-reply
	]
	if ec [
		print "closing the ec channel"
		beer/close-channel ec func [result] [
			either result [
				print "channel ec closed"
				session-done
			] [
				print "failed to close the ec channel"
			]
		]
	]
	]
]

session-done: does [
	beer/destroy-session peer "destroying session"
	peer: ec: ec2: none
]

do-events
