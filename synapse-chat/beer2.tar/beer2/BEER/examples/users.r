; this is an example
; you need to use your own passwords encoded by the encode-pass function
; using an encoding salt chosen by you
; Passwords of login accounts are: "a" "b" "c" "d"
"anonymous" #{} nologin [anonymous]
"initializer" #{898A0CA6D1B414360CDFA5FB2B77BE86882B8D0E} login [initializer]
"admin" #{C7AF6C89E8DACE19D861F245B9503324E12C01AE} login [admin]
"monitor" #{068F9DD677BD3EA3A714769FE2FE107F636B9068} login [monitor]
"root" #{F71C2F645E81504EB9CC7AFC35C7777993957B4D} login [root]
