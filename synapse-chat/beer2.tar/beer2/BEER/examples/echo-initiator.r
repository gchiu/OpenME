Rebol [
	Title: "BEER Sink Profile Initiator Example"
	Date: 4-May-2006/22:00:50+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

#do [
	do %../../paths.r
	[]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %initiator.r
	#include %profiles.r
	#include %management.r
	#include %echo-profile.r
]

beer/open-session atcp://127.0.0.1:8000 func [session] [
	if object? session [
		peer: session
		print ["Connected to listener:" peer/port/sub-port/remote-ip]
		open-s
	]
]

open-s: does [
	beer/open-channel peer 'echo 1.0.0 func [channel] [
		either object? channel [
			print "Echo channel open"
			beer/send-msg channel beer/pack-msg get in beer 'write-MSG "Echo test MSG 1" get in beer 'echo-reply
			beer/send-msg channel beer/pack-msg get in beer 'write-MSG "Echo test MSG 2" get in beer 'echo-reply

		] [print ["didn't succeed to open Echo channel:" channel]]
	]
]

do-events
