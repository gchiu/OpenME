----------------------------------------------------------------------------
 Rebol Styles Pack
 Copyright (C) 2002-2005 Richard Smolak

 Permission to copy, use and modify this software 
 is granted provided this copyright notice appears in all copies. 
 This software is provided "as is" without express or implied
 warranty, and with no claim as to its suitability for any purpose.

 To obtain a commercial license, please contact author.

----------------------------------------------------------------------------
 Contact: cyphre@seznam.cz
----------------------------------------------------------------------------
