Rebol [
	Title: "BEER FT profile Initiator Example"
	Author: "Richard Smolak"
	Date: 30-May-2005/18:15:40+2:00
	License: {
Copyright (C) 2005 Why Wire, Inc.

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Other commercial licenses to this program are available from Why Wire, Inc.
}
]

#do [
	do %../../paths.r
	[]
]


do %styles/my-list.r

stylize/master [
	progress: progress with [
		edge: make edge [size: 0x0 effect: none color: black]
		feel/redraw: func [face act pos][
            face/data: max 0 min 1 face/data
            if face/data <> face/state [
                either face/size/x > face/size/y [
                    face/pane/size/x: max 0 face/data * face/size/x] [
                    face/pane/size/y: max 0 face/data * face/size/y
                    face/pane/offset: face/size - face/pane/size]
                face/state: face/data
                show face/pane]]
	]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

do %encoding-salt.r

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %initiator.r
	#include %profiles.r
	#include %management.r
	#include %auth-profile.r
	#include %ft-profile.r
]

;set path for received files
ft-profile: beer/profile-registry/filetransfer
if ft-profile/destination-dir: %cache-initiator/ [make-dir ft-profile/destination-dir]

beer/open-session atcp://127.0.0.1:8000 func [session] [
	either object? session [
		peer: session
		print ["Connected to listener:" peer/port/sub-port/remote-ip]
		open-ac
	] [print session]
]

open-ac: does [
	beer/open-channel peer 'auth 1.0.0 func [channel] [
		either channel [
			ac: channel
			print "Channel ac open"
			do-login
		] [print "didn't succeed to open the auth channel"]
	]
]

do-login: does [
	beer/login ac "root" "d" func [result] [
		either result [
			print "logged in as Root"
			open-get
		] [print "login unsuccessful"]
	]
]

open-get: does [
	beer/open-channel peer 'filetransfer 1.0.0 func [channel] [
		either channel [
			ft-get: channel
			print "Channel GET open"
			open-post
		] [print "didn't succeed to open unsecure echo channel"]
	]
]

open-post: does [
	beer/open-channel peer 'filetransfer 1.0.0 func [channel] [
		either channel [
			ft-post: channel
			print "Channel POST open"
			do-test
		] [print "didn't succeed to open unsecure echo channel"]
	]
]


do-test: does [

	file-list: copy []
	file-keys: make hash! []
	
	comment {
	callback handler passes ACTION and DATA as an input arguments
	ACTION can be:
		INIT - when the filetransfer is initiated (client gets also filesize info if possible)
		READ - called on each received data chunk
		WRITE - all data are sent (file is fully cached on client side)
		ERROR - triggered due to any error during the transfer
	DATA is a block:
		DATA/1 - unique filename in cache [string!]
		DATA/2 - port! of cached file (used for writing during the transfer) [port!]
		DATA/3 - real filename [string!]
		DATA/4 - the calback function itself [func!]
		DATA/5 - total filesize
		DATA/6 - size of actual received file chunk
		DATA/7 - optional transfer destination directory (%cache/ by default)
	}
	callback-handler: [
		switch action [
			init [
				insert/only tail lst/data compose/deep [(data/3) [data 0 do [edge: make edge [size: 1x1] pane/color: 180.209.238]] (data/5)]
				insert tail file-keys data/1
				lst/update-list
			]
			read [
				ln: 3 * ((idx: index? find file-keys data/1) - (lst/cnt - 1)) - 1
				if bar: lst/grid/pane/:ln [
					bar/data: either data/5 = 0 [
						1
					][
						bar/data + (data/6 / data/5)
					]
					show bar
				]
				ln: pick file-list idx
				either data/5 = 0 [
					ln/2/2: 1
				][
					ln/2/2: ln/2/2 + (data/6 / data/5)
				]
			]
			write [
				;renaming/filexists? routine
				new-name: second split-path data/3
				if  exists? join data/7 new-name [
					print "file exists! changing name..."
					nr: 0
					until [
						nr: nr + 1
						either find tmp-name: copy new-name "." [
							insert find/reverse tail tmp-name "." rejoin ["[" nr "]"]
						][
							insert tail tmp-name rejoin ["[" nr "]"]
						]
						tmp-name: replace/all tmp-name "/" ""
						not exists? join data/7 tmp-name
					]
					new-name: tmp-name
				]
				print ["rename" join data/7 data/1 "to" join data/7 new-name]
				rename join data/7 data/1 new-name
	
				;remove file from gui list
				remove at file-list idx: index? find file-keys data/1
				remove at file-keys idx
				lst/update-list
				
				;remove the all file data from handler's registry(should be done by handler automatically?)
	;			remove/part data 7
	;			ft-profile/files/remove data/1
				
			]
			error []
		]
	]
	
	post-callback-handler: [
		switch action [
			init [
				insert/only tail lst/data compose/deep [(data/3) [data 0 do [edge: make edge [size: 1x1] pane/color: red]] (data/5)]
				insert tail file-keys data/1
				lst/update-list
			]
			read [
				ln: 3 * ((idx: index? find file-keys data/1) - (lst/cnt - 1)) - 1
				if bar: lst/grid/pane/:ln [
					bar/data: either data/5 = 0 [
						1
					][
						bar/data + (data/6 / data/5)
					]
					show bar
				]
				ln: pick file-list idx
				either data/5 = 0 [
					ln/2/2: 1
				][
					ln/2/2: ln/2/2 + (data/6 / data/5)
				]
			]
			write [
				;remove file from gui list
				remove at file-list idx: index? find file-keys data/1
				remove at file-keys idx
				lst/update-list
			]
			error []
		]
	]
	
	view/new layout [
		across
		origin 5
		backcolor 0.164.158
		button "get file(s)" [
			lst/update-list
			get-file/dst-dir ft-get request-file callback-handler dirize to-rebol-file dst-dir/text
		]
		button 150 "get ALL in script dir" [
			lst/update-list
			get-file/dst-dir ft-get read %. callback-handler dirize to-rebol-file dst-dir/text
		]
		text "dest. dir:"
		dst-dir: field 120 "cache-initiator/"
		return
		button "post file(s)" [
			post-file ft-post request-file post-callback-handler
		]
		button 150 "post ALL in script dir" [
			post-file ft-post read %. post-callback-handler
		]
		clk: banner 150 rate 25 with [
			feel: make feel [
				engage: func [f a e][
					if e/type = 'time [
						clk/text: now/time/precise
						show clk
					]
				]
			]
		]
		return
		lst: my-list -1x400 columns [
			text 150x16
			progress 200x16
			text 100x16
		]
		line-colors reduce [white 232.236.241]
		data file-list
		rowbar ["file" "progress" "total size"]
	]
;	lst/update-list
;	get-file/dst-dir ft-get [%rebol.exe] callback-handler dirize to-rebol-file dst-dir/text
]

do-events
halt
