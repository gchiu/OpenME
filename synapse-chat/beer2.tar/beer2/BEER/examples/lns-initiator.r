Rebol [
	Title: "BEER Initiator Example"
	Author: "Richard Smolak"
	Date: 31-May-2006/11:56:51+2:00
]

#do [
	do %../../paths.r
	[]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

do %encoding-salt.r

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %initiator.r
	#include %profiles.r
	#include %management.r
	#include %auth-profile.r
	#include %lns-profile.r
]

beer/open-session atcp://127.0.0.1:8000 func [session] [
	either object? session [
		peer: session
		print ["Connected to listener:" peer/port/sub-port/remote-ip]
		open-ac
	] [print session]
]

open-ac: does [
	beer/open-channel peer 'auth 1.0.0 func [channel] [
		either channel [
			ac: channel
			print "Channel ac open"
			do-login
		] [print "didn't succeed to open the auth channel"]
	]
]

do-login: does [
	beer/login ac "root" "d" func [result] [
		either result [
			print "logged in as Root"
			open-lns
		] [print "login unsuccessful"]
	]
]

open-lns: does [
	beer/open-channel peer 'lns 1.0.0 func [channel] [
		either object? channel [
			lns: channel
			print "Channel LNS open"
			do-test
		] [
			print "didn't succeed to open LNS channel"
			print channel
		]
	]
]

do-test: does [
	my-services: make-service [
		info: [
			name: "my services"
		]
		services: [calc]
		data: [
			calc [
				calc-result: func [input][
					do input
				]
			]
		]
	]

	init?: true

	send-service lns "basic services" [
		[service time]
		[get-time]
		[repeat 1 get-time]
		[after 00:00:05 get-time]
		[schedule (now + 0:0:15) get-time] ;by specifying the time value in paren you force to evaluate it on the listener side(useful when times on both machines differs)
		[service info]
		[service-names]
	] func [channel result /local services id rslt][
		;just some testing callback function
		
		print "LNS CALL RETURNED"
		print "Result:"
		probe result 

		if 'error = first result [
			print "request failed!"
			exit
		]
	;	st: now/time - 500
		if init? [; do this only once
			;get the returned 'thread id' from the first thread request and get the 'listener time' when the thread has been started
			tid: result/6/2/2
			st: result/6/2/3
			init?: false
		]
		
		;check if result is from thread running on the listener
		if parse result ['thread set id string! set rslt any-type!][
			if all [id = tid rslt >= (st/time + 20)][
				;kill the repeating thread after 30 seconds
				send-service lns "basic services" compose/deep [
					[kill-thread (id)]
				] func [channel result][probe result]
			]
			exit
		]

		;check the available services	
		foreach i extract/index result 2 2 [
			if services: select i 'service-names [
				break
			]
		]
		print "adding CALC service..."
		if not find services 'calc [
			publish-service/remote my-services lns func [channel result][
				probe "REMOTE PUBLISHING DONE"
				print ["result:" result]
				print "calling CALC service..."
				send-service lns "my services" [
					[service calc]
					[calc-result 1 + 2 + 5 / 2]
				] func [channel result][
					probe result
				]
	
			]
		]
	]
]

do-events
halt

