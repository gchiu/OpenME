
Rebol [
	Comment: {
		This is an example password encoding salt.
		Use your own value to be safe.
	}
] 
encoding-salt: #{FF44D5422CBF5BFA50D03438CE3CB15B0D457963}
