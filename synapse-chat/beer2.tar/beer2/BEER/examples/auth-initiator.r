Rebol [
	Title: "BEER Auth Initiator Example"
	Date: 30-May-2006/11:43:25+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

#do [
	do %../../paths.r
	[]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

; "runaway locals test"
[
	filetransfer rpc admin close-test monitor anonymous netmask broadcast
	dest-addr nologin initializer callback payload common-rule payload-rule
	read-RPY sink auth
]
query/clear system/words

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %initiator.r
	#include %profiles.r
	#include %management.r
	#include %auth-profile.r
]

beer/open-session atcp://127.0.0.1:8000 func [session] [
	either object? session [
		peer: session
		print ["Connected to listener:" peer/port/sub-port/remote-ip]
		open-ac
	] [print session]
]

open-ac: does [
	beer/open-channel peer 'auth 1.0.0 func [channel] [
		either channel [
			ac: channel
			print "Channel ac open"
			login-adm
		] [print "didn't succeed to open the auth channel"]
	]
]

login-adm: does [
	;beer/login/with ac "admin" #{C7AF6C89E8DACE19D861F245B9503324E12C01AE} func [result] [
	beer/login ac "admin" "b" func [result] [
		either result [
			print "logged in as Admin"
			session-done
		] [print "login unsuccessful"]
	]
]

session-done: does [
	beer/close-channel aa/get peer/channels 0 func [result] [
		either result [
			print "session close successful"
		] [print "session close unsuccessful"]
	]
	;beer/destroy-session peer "destroying session"
	ac: none
	probe query/clear system/words
]

do-events
