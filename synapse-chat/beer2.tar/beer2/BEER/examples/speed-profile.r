Rebol [
	Title: "BEER Speed Profile"
	Date: 10-May-2006/12:19:55+2:00
	Author: "Ladislav Mecir"
	Purpose: {a test profile}
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

speed-reply: none

; speed profile
; the Register function registers a newly created profile
register context [
	; define a name of the profile - a word
	profile: 'speed
	; define a version of the profile
	version: 1.0.0

	; this is an example profile showing some concepts of how a filetransfer
	; profile can be defined
		
	; handler used to initialize a newly created channel
	init: func [
		channel [object!]
		/local info
	] [
		debug ["This is speed profile. Initializing" channel/chno]

		; private channel data managed by the profile should be defined as
		; the channel/prof-data object
		; (do not store private data in the profile!)
		channel/prof-data: make object! [
			; state data for file transfer
			; (every peer can both receive and send files in this implementation)
		
			; receiver state
			total-sizes: copy "" ; total sizes of the files to receive
			received-sizes: none ; really received
			
			; transmitter state
			
			; tell which files are being transferred
			; (this is just a simplification)
			
			files: read testfiles

			; every file with complete path
			foreach file files [insert file testfiles]
			; excluding directories
			remove-each file files [
				info: info? file
				info/type = 'directory
			]
			
			ports: none ; ports to transmitted files
			sizes: none
			send-ans: none ; a function sending the appropriate ANS message
		]
		channel/read-msg: func [
			; this can "properly" send a couple of files
			channel more payload /local prof-data port file
		] [
            ; this is a method using ANS and NUL messages
			payload: to string! payload
            debug ["payload:" mold payload]
            
			; multiple file transfer using ANS
			prof-data: channel/prof-data

			debug "starting transfer"

			debug ["Sending" prof-data/files]
			
			; compute file sizes
			prof-data/sizes: make block! length? prof-data/files
			foreach file prof-data/files [
				file: info? file
				insert tail prof-data/sizes file/size
			]
			
			; open file ports
			prof-data/ports: make block! length? prof-data/files
			repeat i length? prof-data/files [
				file: prof-data/files/:i
				insert/only tail prof-data/ports reduce [
					open/binary/direct file i prof-data/sizes/:i
				]
			]
			
			prof-data/sizes: mold/only prof-data/sizes
			prof-data/send-ans: :send-file-sizes
			send-reply channel func [channel] [
				channel/prof-data/send-ans channel
			]
		]
		; close handler
		channel/close: func [channel /ask] [
			; this is the smallest possible implementation,
			; it just accepts close (i.e. does not return any error)
			; (if we wanted to refuse the close request,
			; it would be best to return an ERR frame payload string
			; specifying the problem to peer instead)
			none
		]
	]
	send-file-sizes: func [channel /local prof-data pl more size] [
		prof-data: channel/prof-data
		size: min channel/out-window MAXSIZE
		either size < length? prof-data/sizes [
			more: "*"
			pl: copy/part prof-data/sizes size
			prof-data/sizes: skip prof-data/sizes size
		] [
			more: "."
			pl: prof-data/sizes
			prof-data/send-ans: :send-files
		]
		write-ANS channel more 0 pl
	]
	send-files: func [
		channel /local size prof-data port ansnum file-size data payload more
	] [
		; the maximum size that can be sent
		size: min channel/out-window MAXSIZE
		prof-data: channel/prof-data
		; this transmits the contents of the files
		; in a round-robin fashion (i.e. in a "parallel" way)
		; pick a port
		set [port ansnum file-size] data: first prof-data/ports
		size: min size file-size
		; this would be real file read:
		; payload: copy/part port size
		; this is just a simulation eliminating file input:
		payload: head insert/dup copy #{} #"0" size

		file-size: file-size - size
		data/3: file-size

		; robin
		more: either file-size > 0 [
			prof-data/ports: next prof-data/ports
			"*"
		] [
			close port
			remove prof-data/ports
			"."
		]
		; round
		if tail? prof-data/ports [prof-data/ports: head prof-data/ports]
		
		write-ANS channel more ansnum payload
		if empty? prof-data/ports [write-NUL channel]
	]
	; defining a handler that can be used to read a peer reply
	set 'speed-reply func [
		msg channel more ansno payload /local prof-data total
	] [
		;debug [
		;	"speed-profile received:" msg channel/chno more ansno mold payload
		;]
		
		; we will access the profile data
		prof-data: channel/prof-data
		
		; a read handler can (in general) obtain the following message types:
		; RPY, ERR, ANS, NUL
		
		; this handler wants to handle only two message types: ANS and NUL
		unless find ["ANS" "NUL"] msg [
			poorly-formed rejoin ["speed-reply: " msg " not expected"]
		]
		
		; the reason why we use ANS messages to transfer the files is,
		; that we can transfer many files at once this way
		
		; the NUL message is used to finish the transfer
		
		either msg <> "NUL" [
			either ansno = 0 [
				; the frame with ansno = 0 is supposed to contain
				; the total sizes of the transferred files,
				; while the other ANS frames are used to transfer
				; the contents of the files,
				; i.e. the count of ANS messages is equal to
				; the number of the transferred files plus one
				
				; defragment the frame, 40'000 is an arbitrary limit
				payload: defragment in prof-data 'total-sizes more payload 40'000 [
					poorly-formed "speed-test: too many files"
				]
				; get file sizes
				if error? try [prof-data/total-sizes: load/all payload] [
					poorly-formed "speed-test: wrong file sizes"
				]
				; check file sizes
				foreach file-size prof-data/total-sizes [
					unless integer? file-size [
						poorly-formed "speed-test: wrong file sizes"
					]
				]
				debug ["total sizes:" mold prof-data/total-sizes]
				
				; we may start to receive the files
				prof-data/received-sizes: head insert/dup copy [
				] 0 length? prof-data/total-sizes
				start-time: now/precise
			] [
				; receiving a file, take the appropriate action
				poke prof-data/received-sizes ansno prof-data/received-sizes/:ansno + length? payload
				; the code below could immediately print the information, if needed
				;print [
				;	"file" ansno
				;	prof-data/received-sizes/:ansno "received from"
				;	prof-data/total-sizes/:ansno "total"
				;]
				if more = "." [
					print ["file" ansno "completely received"]
				]
			]
		] [
			; NUL received, reception done
			stop-time: now/precise
			; computing the total received size
			total: 0
			foreach size prof-data/total-sizes [total: total + size]
			debug [
				"received sizes" prof-data/received-sizes newline
				"stop-time:" stop-time: to decimal! difference stop-time start-time newline
				"transmission speed:"
				transmission-speed: either zero? stop-time [
					"undetermined, increase file sizes, please"
				] [
					transmission-speed: round total * 8 / stop-time * 1e-3
				]
				"[kbps]"
			]
			print "All files received"
			prof-data/total-sizes: none
		]
	]
]
