Rebol [
	Title: "BEER Echo profile"
	Date: 10-May-2006/17:41:37+2:00
	Author: "Ladislav Mecir"
	Purpose: {
		An example/test profile
		For every MSG received the Echo profile sends it as a reply
	}
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

echo-reply: none

register context [
	profile: 'echo
	version: 1.0.0

	; initial handler
	init: func [channel [object!]] [
		debug ["Echo profile: initializing channel" channel/chno]
		channel/prof-data: make object! [
			; to keep track of the MSG fragments
			fragment: copy ""
		]
		channel/read-msg: func [channel more payload] [
            debug ["Echo profile:" "MSG" more mold payload]
            ; defragment the message, set limit to 4'000
            ; (the limit is arbitrary, any other value can be used)
			payload: defragment in channel/prof-data 'fragment more payload 4'000 [
				poorly-formed "Echo message limit exceeded"
			]
			; send the reply
			send-reply channel pack-msg :write-RPY payload
		]
		; close handler
		channel/close: func [channel /ask] [
			either ask [debug "channel close asked"] [
				debug "channel close processing"
			]
			none
		]
	]
	set 'echo-reply func [
		{this is how an Echo reply can be processed}
		msg channel more ansno payload
	] [
		debug ["Echo reply:" msg more ansno mold payload]
		if msg <> "RPY" [poorly-formed "Echo profile: RPY reply expected"]	
	]
]
