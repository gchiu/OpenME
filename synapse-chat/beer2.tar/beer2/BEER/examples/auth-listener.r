Rebol [
	Title: "BEER Auth Listener Example"
	Date: 24-May-2006/23:54:30+2:00
	Author: "Ladislav Mecir"
	License: {Copyright (C) 2006 Why Wire, Inc.}
]

#do [
	do %../../paths.r
	[]
]

#include-check %aa.r
#include-check %catch.r
#include-check %unsigned.r
#include-check %iatcp-protocol.r

do %encoding-salt.r

; "runaway locals test"
[
	filetransfer rpc admin close-test monitor anonymous netmask broadcast
	dest-addr nologin initializer callback payload common-rule payload-rule
	read-RPY sink auth
]
query/clear system/words

beer: make object! [
	groups: load %groups.r
	users: load %users.r
	#include %channel.r
	#include %authenticate.r
	#include %beer-read.r
	#include %framesend.r
	#include %session-handler.r
	#include %listener.r
	#include %profiles.r
	#include %management.r
	#include %auth-profile.r
]

beer/open-listener 8000

probe query system/words

print "auth listener's up!"

do-events
